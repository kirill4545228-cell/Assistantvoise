package com.example.voiceassistant

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Button
import android.widget.TextView

class MainActivity : Activity() {

    data class Track(val id: Long, val title: String, val artist: String)

    private lateinit var status: TextView
    private lateinit var btn: Button
    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var tracks = listOf<Track>()
    private var queue = listOf<Track>()
    private var idx = 0
    private var player: MediaPlayer? = null

    // Русские названия -> часть настоящего названия приложения
    private val aliases = mapOf(
        "ютуб" to "youtube", "ютьюб" to "youtube", "телеграм" to "telegram",
        "телеграмм" to "telegram", "вотсап" to "whatsapp", "ватсап" to "whatsapp",
        "хром" to "chrome", "гугл" to "google", "вк" to "vk", "вконтакте" to "vk",
        "инстаграм" to "instagram", "тикток" to "tiktok", "спотифай" to "spotify",
        "карты" to "maps", "почта" to "gmail", "настройки" to "settings",
        "камера" to "camera", "галерея" to "gallery", "контакты" to "contacts"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        btn = findViewById(R.id.btn)
        btn.setOnClickListener { if (listening) stopListening() else startListening() }

        val audioPerm = if (Build.VERSION.SDK_INT >= 33)
            Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, audioPerm), 1)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        loadTracks()
    }

    override fun onPause() {
        super.onPause()
        stopListening()
    }

    override fun onDestroy() {
        super.onDestroy()
        player?.release()
    }

    // ---------- Голос ----------
    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            status.text = "Нет доступа к микрофону"; return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Распознавание речи недоступно на устройстве"; return
        }
        listening = true
        btn.text = "Остановить"
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(listener)
        }
        listenOnce()
    }

    private fun stopListening() {
        listening = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        recognizer = null
        btn.text = "Слушать"
    }

    private fun listenOnce() {
        if (!listening) return
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        recognizer?.startListening(i)
        status.text = "Слушаю…"
    }

    private val listener = object : RecognitionListener {
        override fun onResults(results: android.os.Bundle?) {
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (text != null) handle(text.lowercase().trim())
            handler.postDelayed({ listenOnce() }, 400)
        }
        override fun onError(error: Int) {
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { stopListening(); return }
            handler.postDelayed({ listenOnce() }, 600)
        }
        override fun onReadyForSpeech(p: android.os.Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(p: android.os.Bundle?) {}
        override fun onEvent(t: Int, p: android.os.Bundle?) {}
    }

    // ---------- Команды ----------
    private fun handle(text: String) {
        status.text = "Вы сказали: $text"
        val open = listOf("открой ", "открыть ", "запусти ", "запустить ")
        val play = listOf("включи ", "поставь ", "играй ", "включить ")
        when {
            open.any { text.startsWith(it) } ->
                openApp(text.substringAfter(' ').trim())
            "следующ" in text -> next()
            "пауза" in text || "стоп" in text || "останови" in text -> player?.pause()
            "продолжи" in text || "дальше играй" in text -> player?.start()
            play.any { text.startsWith(it) } -> {
                val q = text.substringAfter(' ').trim()
                if (q.isEmpty() || "музык" in q) playRandom() else playSearch(q)
            }
            else -> status.text = "Не понял: $text"
        }
    }

    private fun openApp(nameRaw: String) {
        val name = aliases[nameRaw] ?: nameRaw
        val pm = packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val app = pm.queryIntentActivities(main, 0).firstOrNull {
            it.loadLabel(pm).toString().lowercase().contains(name)
        }
        if (app == null) { status.text = "Приложение «$nameRaw» не найдено"; return }
        val launch = pm.getLaunchIntentForPackage(app.activityInfo.packageName)
        if (launch != null) {
            status.text = "Открываю ${app.loadLabel(pm)}"
            startActivity(launch)
        }
    }

    // ---------- Музыка ----------
    private fun loadTracks() {
        if (checkSelfPermission(
                if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
                else Manifest.permission.READ_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED) return
        val list = mutableListOf<Track>()
        val cols = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST)
        contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, cols,
            "${MediaStore.Audio.Media.IS_MUSIC} != 0", null, null
        )?.use { c ->
            while (c.moveToNext()) list.add(Track(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: ""))
        }
        tracks = list
        status.text = "Найдено треков: ${tracks.size}"
    }

    private fun playRandom() {
        if (tracks.isEmpty()) { status.text = "На устройстве нет музыки"; return }
        playQueue(tracks.shuffled(), 0)
    }

    private fun playSearch(q: String) {
        val found = tracks.filter { it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) }
        if (found.isEmpty()) { status.text = "Не нашёл «$q»"; return }
        playQueue(found, 0)
    }

    private fun playQueue(list: List<Track>, start: Int) {
        queue = list; idx = start; playCurrent()
    }

    private fun playCurrent() {
        val t = queue.getOrNull(idx) ?: return
        player?.release()
        val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, t.id)
        player = MediaPlayer().apply {
            setDataSource(this@MainActivity, uri)
            setOnCompletionListener { next() }
            prepare()
            start()
        }
        status.text = "Играет: ${t.artist} — ${t.title}"
    }

    private fun next() {
        if (queue.isEmpty()) return
        idx = (idx + 1) % queue.size
        playCurrent()
    }
}
